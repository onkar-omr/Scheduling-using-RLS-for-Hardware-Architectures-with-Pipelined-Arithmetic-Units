%GRAPHTOSTRUCT convert graph object to struct.
%    struct = GRAPHTOSTRUCT(variable, name) returns (xml)struct which
%      include all information from variable.
%  
%     See also structtoxml, graph (scheduling toolbox)

%   Author(s): M. Kutil, V. Navratil
%   Copyright (c) 2005
%   $Revision: 2892 $  $Date: 2009-03-18 10:20:37 +0100 (st, 18 III 2009) $

